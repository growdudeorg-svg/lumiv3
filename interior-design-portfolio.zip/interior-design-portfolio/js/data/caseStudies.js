/**
 * Case Studies Configuration matching exact UI design
 * Brand: Lumicentric (Mumbai, Maharashtra)
 */

export const CASE_STUDIES_DATA = [
  {
    id: "complete-home-transformation",
    eyebrow: "CASE STUDY",
    title: "A Complete Home Transformation",
    subtitle: "Lodha World Crest Penthouse, Worli, Mumbai",
    summary: "See how we turned a blank canvas into a warm, elegant and functional home for a Mumbai family.",
    image: "assets/images/case-study-hero.jpg",
    area: "3,400 sq.ft.",
    timeline: "8 Weeks",
    clientFamily: "Senior Financial Executive & Family (Mumbai)",
    milestones: [
      {
        number: "01",
        title: "Client Requirements",
        desc: "A modern, clutter-free home with ample storage, warm ambient evening light, and an open layout for hosting friends."
      },
      {
        number: "02",
        title: "Our Approach",
        desc: "Custom, contemporary design with warm tones, natural fluted walnut louvers, and bespoke concealed modular solutions."
      },
      {
        number: "03",
        title: "Execution",
        desc: "8-week timeline, turnkey execution with dedicated project management, civil modifications, and daily progress logs."
      },
      {
        number: "04",
        title: "The Result",
        desc: "A beautiful, functional home delivered on time with zero budget surprises and 100% verified material compliance."
      }
    ],
    deepPhases: [
      {
        phase: "Phase 1: Civil Reconfiguration & Concealed MEP",
        duration: "Days 1-14",
        details: "Demolished non-loadbearing partition between formal living and dining to achieve an expansive open floor plan. Installed sound-dampened plumbing lines and Schneider multi-zone lighting automation conduits."
      },
      {
        phase: "Phase 2: Architectural Ceilings & Fluted Wall Paneling",
        duration: "Days 15-28",
        details: "Erected multi-tier recessed cove tray false ceilings with 3000K warm diffused light channels. Clad the 22-foot accent wall with hand-selected FSC-certified American walnut fluted acoustic battens."
      },
      {
        phase: "Phase 3: Precision Modular Cabinetry & Stone Installation",
        duration: "Days 29-45",
        details: "Delivered factory-cut BWP 710 marine carcasses and FENIX thermal-healing shutters from our precision manufacturing facility. Laid large-format book-matched Statuario marble slabs in the formal living zone."
      },
      {
        phase: "Phase 4: Custom Furniture, Curtains & Deep Cleaning Handover",
        duration: "Days 46-56",
        details: "Installed custom modular sectional sofa upholstered in stain-resistant textured boucle fabric, motorized sheer linen drapes, followed by industrial HEPA dust vacuuming and snag-free handover."
      }
    ]
  }
];
