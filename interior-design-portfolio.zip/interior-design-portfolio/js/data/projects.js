/**
 * Projects Configuration matching exact UI design
 * Brand: Lumicentric (Mumbai, Maharashtra)
 */

export const PROJECTS_DATA = [
  {
    id: "serenity-apartment",
    title: "Serenity Apartment",
    subtitle: "Warm Minimalist 3BHK Residence",
    category: "residential",
    categoryLabel: "Residential Interior",
    location: "Worli Sea Face, Mumbai",
    area: "1,850 sq.ft.",
    year: "2025-2026",
    completionStatus: "Completed • Handed Over",
    scopeTags: ["Living Room", "Concealed LED", "Floating Console", "Warm Minimalist"],
    coverImage: "assets/images/project-serenity.jpg",
    beforeImage: "assets/images/comparison-before.jpg",
    afterImage: "assets/images/comparison-after.jpg",
    gallery: [
      { url: "assets/images/project-serenity.jpg", caption: "Bespoke Walnut Floating Console with Warm Ambient Backlighting" },
      { url: "assets/images/hero-main.jpg", caption: "Spacious Open Living and Dining Flow" },
      { url: "assets/images/about-dining.jpg", caption: "Dining Zone with Natural Oak and Green Wall" }
    ],
    brief: "The homeowners desired a peaceful, uncluttered haven in Mumbai that balances warm Scandinavian minimalism with rich organic textures and ambient evening illumination.",
    challenges: [
      "Low natural ceiling height required slimline recessed tray lighting.",
      "Maximizing living room circulation while accommodating deep media console storage.",
      "Concealing all wiring and home theatre conduits within fluted acoustic panels."
    ],
    designDecisions: [
      "Floating walnut media console with indirect 3000K warm LED illumination.",
      "Textured Venetian plaster accent walls for tactile warmth.",
      "Sheer linen floor-to-ceiling drapes filtering bright afternoon sunlight."
    ],
    verifiedSpecs: {
      "Civil & Joinery": "Marine BWP Grade Plywood with Natural Walnut Veneer",
      "Lighting System": "3000K Warm Architectural Dimmable COB & Strip LEDs",
      "Wall Finishes": "Lime-based Venetian Plaster & Low-VOC Matte Coatings",
      "Hardware": "Hafele Push-to-Open Concealed German Mechanisms",
      "Timeline": "60 Days from Blueprint Sign-off to Final Styling"
    },
    testimonial: {
      client: "Rohit & Priya",
      society: "Lodha World Crest, Worli, Mumbai",
      quote: "The Lumicentric team completely transformed our home. Professional, creative and an absolute pleasure to work with!"
    }
  },
  {
    id: "the-urban-office",
    title: "The Urban Office",
    subtitle: "High-Performance Executive Suite & Boardroom",
    category: "commercial",
    categoryLabel: "Commercial Interior",
    location: "BKC, Mumbai",
    area: "3,200 sq.ft.",
    year: "2025",
    completionStatus: "Completed • Handed Over",
    scopeTags: ["Commercial Office", "Boardroom", "Acoustic Glass", "Live Edge Table"],
    coverImage: "assets/images/project-urban-office.jpg",
    beforeImage: "assets/images/comparison-before.jpg",
    afterImage: "assets/images/project-urban-office.jpg",
    gallery: [
      { url: "assets/images/project-urban-office.jpg", caption: "Executive Boardroom with Live Edge Walnut Table" },
      { url: "assets/images/service-commercial.jpg", caption: "Acoustic Glass Partitions and Collaborative Space" }
    ],
    brief: "A high-growth tech consultancy required an executive workspace in BKC reflecting modern sophistication, acoustic privacy, and seamless video collaboration capabilities.",
    challenges: [
      "High ambient street noise required double-glazed STC 42 acoustic partitions.",
      "Integrating concealed 16-channel video conferencing without exposed wires.",
      "Strict 45-day commercial delivery deadline before lease commencement."
    ],
    designDecisions: [
      "Live-edge natural walnut 14-seater boardroom table with motorized pop-up connectivity.",
      "Slatted acoustic oak ceiling with recessed micro-louvers for optimal speech clarity.",
      "Double-glazed acoustic partitions with black powder-coated aluminum framing."
    ],
    verifiedSpecs: {
      "Acoustic Rating": "STC 42 Acoustic Glass Partitions & Ceilings",
      "Woodwork": "FSC-Certified Solid Walnut & Reconstituted Oak Veneers",
      "Ergonomics": "Herman Miller Aeron & Embody Task Seating",
      "AV Infrastructure": "Biamp DSP, Logitech Rally Plus 4K Video System",
      "Timeline": "42 Days Complete Turnkey Execution"
    },
    testimonial: {
      client: "Amit Deshmukh",
      society: "The Capital, BKC, Mumbai",
      quote: "Excellent execution and attention to detail by Lumicentric. Our office looks stunning and our team loves the space."
    }
  },
  {
    id: "modern-villa",
    title: "Modern Villa",
    subtitle: "Expansive 4BHK Private Retreat",
    category: "turnkey",
    categoryLabel: "Turnkey Project",
    location: "Juhu Scheme, Mumbai",
    area: "4,600 sq.ft.",
    year: "2026",
    completionStatus: "Completed • Turnkey Handover",
    scopeTags: ["Turnkey Villa", "Master Bedroom", "Tufted Headboard", "Garden View"],
    coverImage: "assets/images/project-modern-villa.jpg",
    beforeImage: "assets/images/comparison-before.jpg",
    afterImage: "assets/images/project-modern-villa.jpg",
    gallery: [
      { url: "assets/images/project-modern-villa.jpg", caption: "Luxury Master Suite with Tufted Headboard & Slat Wall" },
      { url: "assets/images/case-study-hero.jpg", caption: "Grand Double-Height Living Room" },
      { url: "assets/images/about-dining.jpg", caption: "Private Courtyard Dining" }
    ],
    brief: "Complete turnkey design and build of a private coastal residence in Juhu, emphasizing luxury tactile materials, seamless indoor-outdoor connections, and custom furniture.",
    challenges: [
      "Coastal saline humidity in Mumbai required specialized marine grade 710 substrates and anti-corrosion fittings throughout.",
      "Coordinating imported tufted upholstery and custom brass light fixtures from Europe.",
      "Managing multi-level MEP engineering without lowering finished floor-to-ceiling heights."
    ],
    designDecisions: [
      "Full-height upholstered tufted headboard backed by warm acoustic walnut fluting.",
      "Ambient floating perimeter cove lighting creating an intimate luxury sanctuary.",
      "Minimalist sliding glass doors leading out to private landscaped zen gardens."
    ],
    verifiedSpecs: {
      "Joinery Base": "Century Pro BWP 710 Club Marine Grade Core",
      "Finishes": "Hand-buffed Italian Polyurethane & Smoked Oak Veneer",
      "Bedding": "Custom Belgian Linen & High-Resilience Memory Foam Core",
      "Automation": "Lutron Palladiom Lighting & Climate Keypads",
      "Timeline": "85 Days Full Turnkey Handover"
    },
    testimonial: {
      client: "Dr. Sandeep & Neha Joshi",
      society: "Gulmohar Road, Juhu, Mumbai",
      quote: "Lumicentric delivered beyond what we imagined. From civil to the final curtain rod, every milestone was transparent."
    }
  },
  {
    id: "epoxy-showroom",
    title: "Epoxy Showroom",
    subtitle: "Architectural Surface Experience Center",
    category: "flooring",
    categoryLabel: "Flooring Solution",
    location: "Lower Parel, Mumbai",
    area: "2,200 sq.ft.",
    year: "2025-2026",
    completionStatus: "Completed • Handed Over",
    scopeTags: ["Seamless Epoxy", "Metallic Blue", "Architectural Arches", "Commercial Surface"],
    coverImage: "assets/images/project-epoxy-showroom.jpg",
    beforeImage: "assets/images/comparison-before.jpg",
    afterImage: "assets/images/project-epoxy-showroom.jpg",
    gallery: [
      { url: "assets/images/project-epoxy-showroom.jpg", caption: "Mirror-Finish Ocean Metallic Epoxy Resin Flooring with Arches" },
      { url: "assets/images/service-flooring.jpg", caption: "Engineered Wood and Microcement Transition" }
    ],
    brief: "A bespoke surface showroom in Lower Parel showcasing the future of joint-free architectural flooring, featuring metallic swirling epoxy, warm stone arches, and modern gallery pedestals.",
    challenges: [
      "Subfloor in historic mill compound required deep diamond grinding and moisture barrier priming.",
      "Achieving flawless optical clarity with zero dust particles in a high-traffic urban zone.",
      "Ensuring ASTM D4060 abrasion resistance for heavy footwear traffic."
    ],
    designDecisions: [
      "Triple-layer metallic resin pour with dual-tone midnight cobalt and pearlescent platinum mica.",
      "High-solids aliphatic polyurethane clear coat with anti-scratch nano-ceramic additives.",
      "Continuous seamless finish curving gracefully up into matching cove baseboards."
    ],
    verifiedSpecs: {
      "System": "3.5mm Multi-Layer Self-Leveling Metallic Epoxy + PU Shield",
      "Adhesion Strength": "ASTM D4541 > 3.8 MPa (Concrete substrate failure)",
      "Hardness": "Shore D 84 (ASTM D2240)",
      "VOC Level": "< 10 g/L (Zero VOC, LEED Compliant)",
      "Timeline": "12 Days Substrate Prep to Final Handover"
    },
    testimonial: {
      client: "Sneha Patil",
      society: "Phoenix Palladium Mills, Lower Parel, Mumbai",
      quote: "Their epoxy flooring work is top notch. Durable, clean and gives a truly premium, mirror-like look!"
    }
  },
  {
    id: "modular-kitchen-wakad",
    title: "Aura Modular Kitchen",
    subtitle: "German Engineered Modular Kitchen & Pantry",
    category: "modular",
    categoryLabel: "Modular Interiors",
    location: "Powai, Mumbai",
    area: "260 sq.ft.",
    year: "2026",
    completionStatus: "Completed • Handed Over",
    scopeTags: ["Modular Kitchen", "Quartz Counter", "Hafele Blum", "Anti-Fingerprint"],
    coverImage: "assets/images/service-modular.jpg",
    beforeImage: "assets/images/comparison-before.jpg",
    afterImage: "assets/images/service-modular.jpg",
    gallery: [
      { url: "assets/images/service-modular.jpg", caption: "Matte Charcoal Modular Kitchen with Quartz Island" }
    ],
    brief: "Sleek, ergonomic German-engineered modular kitchen designed for high-heat, spice-rich Indian cooking with effortless wipe-down surfaces.",
    challenges: [
      "Awkward structural pillar required custom blind-corner carousel engineering.",
      "Maximizing pantry storage within a 12x18 foot galley footprint."
    ],
    designDecisions: [
      "Anti-fingerprint thermal matte acrylic shutters in slate charcoal.",
      "Seamless quartz countertop with integrated undermount sink and waterfall island edge.",
      "Hands-free motion sensor LED task lighting under upper wall units."
    ],
    verifiedSpecs: {
      "Carcass": "18mm BWP 710 Boiling Waterproof Marine Plywood",
      "Shutters": "FENIX NTM Nano-Tech Matte Thermal Healing Laminate",
      "Fittings": "Blum Legrabox Soft-Close + Tip-On Push Mechanisms",
      "Appliances": "Siemens iQ700 Induction Hob, Built-in Oven & 14-Place Dishwasher",
      "Timeline": "28 Days Factory Build, 3 Days On-Site Installation"
    },
    testimonial: {
      client: "Pooja & Sameer Kulkarni",
      society: "Hiranandani Gardens, Powai, Mumbai",
      quote: "The Lumicentric modular kitchen fits our lifestyle so well. Super easy to clean, silent drawers, and looks out of an international magazine."
    }
  }
];
