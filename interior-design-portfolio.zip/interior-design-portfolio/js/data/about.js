/**
 * About Us Configuration matching exact UI design
 * Brand: Lumicentric (Mumbai, Maharashtra)
 */

export const ABOUT_DATA = {
  eyebrow: "ABOUT US",
  title: "Design. Execute. Deliver.",
  description: "We are a Mumbai-based interior design and execution company passionate about creating spaces that are beautiful, functional and built to last. With a focus on quality, transparency and personalised service, we turn ideas into inspiring spaces.",
  ctaText: "Know More About Us",
  image: "assets/images/about-dining.jpg",
  pillars: [
    {
      title: "Client-Centric Approach",
      desc: "Tailored spatial layouts and curated material palettes reflecting your individual personality.",
      icon: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>`
    },
    {
      title: "Quality Craftsmanship",
      desc: "Factory-precision edge-banding, authentic European hardware, and zero tolerance on structural finish quality.",
      icon: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>`
    },
    {
      title: "On-Time Delivery",
      desc: "Strict milestone tracking with defined handover dates backed by contractual delivery commitments.",
      icon: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>`
    },
    {
      title: "End-to-End Support",
      desc: "Dedicated site engineers, single point of contact, and continuous post-handover warranty care.",
      icon: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path></svg>`
    }
  ],
  studioStory: "Founded by senior architects and civil engineers in Mumbai, Lumicentric Interiors brings together German engineering precision with warm, livable aesthetics. Operating across South Mumbai, Western Suburbs, and Central Mumbai, we eliminate middlemen and maintain 100% control over quality."
};
