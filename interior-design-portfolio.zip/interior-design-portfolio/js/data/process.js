/**
 * Process Steps matching exact UI design
 */

export const PROCESS_DATA = [
  {
    step: "01",
    name: "Discover",
    short: "Understand your needs",
    description: "Detailed initial consultation at our Baner studio or your site to understand your family's lifestyle, functional priorities, and aesthetic tastes.",
    icon: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>`
  },
  {
    step: "02",
    name: "Plan",
    short: "Site study & space planning",
    description: "Laser measurement survey of your site in Pune, zoning, space optimization, traffic flow analysis, and preliminary structural feasibility study.",
    icon: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75"><rect x="3" y="3" width="18" height="18" rx="2"></rect><line x1="3" y1="9" x2="21" y2="9"></line><line x1="9" y1="21" x2="9" y2="9"></line></svg>`
  },
  {
    step: "03",
    name: "Design",
    short: "Concepts, materials & 3D visuals",
    description: "Photo-realistic 3D walkthrough renders, moodboards, material palettes, lighting plans, and tactile finish samples presented for your approval.",
    icon: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75"><path d="M12 19l7-7 3 3-7 7-3-3z"></path><path d="M18 13l-1.5-7.5L2 2l3.5 14.5L13 18l5-5z"></path><path d="M2 2l7.586 7.586"></path><circle cx="11" cy="11" r="2"></circle></svg>`
  },
  {
    step: "04",
    name: "Estimate",
    short: "Transparent quotation",
    description: "Line-itemized BOQ (Bill of Quantities) with brand-specified materials, zero hidden clauses, transparent milestone stages, and fixed-cost guarantee.",
    icon: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg>`
  },
  {
    step: "05",
    name: "Execute",
    short: "Skilled execution & quality checks",
    description: "Dedicated full-time civil engineer on site, dust-controlled factory precision modular fabrication, and daily photo/video WhatsApp progress logs.",
    icon: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"></path></svg>`
  },
  {
    step: "06",
    name: "Handover",
    short: "On-time delivery & support",
    description: "Deep industrial cleaning, 80-point quality audit, key handover celebration, warranty documentation packet, and 10-year post-handover service support.",
    icon: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75"><path d="M21 2l-2 2m-1-1l-3 3m4 0l-2 2m-5-1l-2 2m4 0l-2 2m-7-1l-2 2m4 0l-2 2"></path><circle cx="7" cy="17" r="5"></circle></svg>`
  }
];
