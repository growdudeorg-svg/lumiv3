/**
 * Testimonials Configuration matching exact UI design
 * Brand: Lumicentric (Mumbai, Maharashtra)
 */

export const TESTIMONIALS_DATA = [
  {
    id: "testimonial-1",
    quote: "The Lumicentric team completely transformed our home. Professional, creative and a pleasure to work with!",
    clientName: "Rohit & Priya",
    role: "Homeowners, Mumbai",
    projectType: "3BHK Luxury Turnkey Residence",
    locality: "Worli, Mumbai",
    rating: 5,
    avatar: "assets/images/avatar-rohit-priya.jpg"
  },
  {
    id: "testimonial-2",
    quote: "Excellent execution and attention to detail. Our office looks stunning and our team loves the space.",
    clientName: "Amit Deshmukh",
    role: "Business Owner, Mumbai",
    projectType: "Commercial Executive Office",
    locality: "BKC, Mumbai",
    rating: 5,
    avatar: "assets/images/avatar-amit.jpg"
  },
  {
    id: "testimonial-3",
    quote: "Their epoxy flooring work is top notch. Durable, clean and gives a premium look.",
    clientName: "Sneha Patil",
    role: "Retail Store Owner, Mumbai",
    projectType: "Bespoke Seamless Flooring",
    locality: "Juhu, Mumbai",
    rating: 5,
    avatar: "assets/images/avatar-sneha.jpg"
  }
];
