/**
 * Studio Differentiators & Operational Advantages
 * Studio: Anvaya Atelier (Pune, Maharashtra)
 * Note: Evidence-led capabilities, no inflated claims.
 */

export const DIFFERENTIATORS_DATA = [
  {
    id: "diff-01",
    number: "01",
    title: "100% In-House Site Engineering",
    subtitle: "Zero Blind Subcontracting",
    description: "Unlike interior aggregators who sell leads to unknown local contractors, Anvaya deploys our own salaried civil engineers and project managers on your site every single day. One unified team takes end-to-end accountability.",
    evidenceBadge: "Dedicated Daily Site Engineer",
    icon: "shield-user"
  },
  {
    id: "diff-02",
    number: "02",
    title: "Bhosari CNC Pre-Fabrication",
    subtitle: "Factory Calibrated Precision",
    description: "All modular joinery is cut on automated German beam saws with 1mm moisture-proof PUR hot-air edge banding. We eliminate on-site saw dust, wavy hand-cut edges, and premature laminate bubbling.",
    evidenceBadge: "45-Day Handover Protocol",
    icon: "factory"
  },
  {
    id: "diff-03",
    number: "03",
    title: "Transparent, Zero-Escalation BOQ",
    subtitle: "Every Hardware Model in Writing",
    description: "We provide an exhaustive, line-by-line itemized Bill of Quantities with certified brand names (Century 710, Blum Legrabox, Saint-Gobain). Once contracted, your project cost is strictly fixed with zero surprise markups.",
    evidenceBadge: "Fixed-Price Guarantee",
    icon: "receipt"
  },
  {
    id: "diff-04",
    number: "04",
    title: "Specialized Epoxy & Microcement Division",
    subtitle: "Engineering Continuous Grout-Free Surfaces",
    description: "We possess our own industrial planetary diamond grinders, HEPA dust collectors, and certified resin applicators. We transform broken builder tiles into seamless, joint-free resin planes in 8 to 10 days.",
    evidenceBadge: "28,000+ Sq.Ft. Executed",
    icon: "layers"
  },
  {
    id: "diff-05",
    number: "05",
    title: "45-Point Systematic Quality Audits",
    subtitle: "Laser Checked Alignment",
    description: "Prior to hand-over, our Quality Assurance principal inspects door clearances with digital calipers, checks water pressure, tests electrical circuits, and verifies false ceiling deflection tolerances.",
    evidenceBadge: "Signed QA Dossier Provided",
    icon: "checklist"
  },
  {
    id: "diff-06",
    number: "06",
    title: "10-Year Hardware & 48-Hour Service",
    subtitle: "Long-Term Local Support in Pune",
    description: "We stand behind our work. All Blum and Hettich moving systems carry a 10-year replacement warranty, supported by our permanent Pune service van with a committed 48-hour on-site turnaround.",
    evidenceBadge: "Committed 48-Hour Pune Service",
    icon: "clock"
  }
];
