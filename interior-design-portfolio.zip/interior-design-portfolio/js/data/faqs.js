/**
 * Frequently Asked Questions (FAQ) Data
 * Studio: Anvaya Atelier (Pune, Maharashtra)
 * Note: Candid answers reflecting authentic studio operational policies.
 */

export const FAQS_DATA = [
  {
    id: "faq-01",
    category: "Cost & Commercials",
    question: "How does turnkey interior pricing work, and can the budget escalate during execution?",
    answer: "Our turnkey contracts operate on an itemized, line-by-line Bill of Quantities (BOQ). Before any work starts or advances are accepted, we finalize every material brand, square footage, hardware model number, and lighting spec in writing. Once the contract is signed, the price is strictly fixed—there are zero unexpected escalation clauses. Cost revisions occur only if you choose to alter the physical scope or upgrade finishes during the project, and these are always approved in writing via a formal change order before execution."
  },
  {
    id: "faq-02",
    category: "Timelines & Delivery",
    question: "What is the typical completion timeline for a 2BHK, 3BHK, or 4BHK apartment in Pune?",
    answer: "A modular kitchen and wardrobe package typically takes 35 to 45 days. A complete turnkey residential interior (including civil modifications, electrical MEP, false ceilings, modular woodwork, painting, and deep cleaning) takes 60 to 75 days for a 3BHK, and 75 to 90 days for a 4BHK or penthouse. Because we pre-fabricate all modular elements in our Bhosari factory simultaneously while civil work happens on-site, we reduce overall completion time by 3 to 4 weeks compared to traditional on-site carpentry."
  },
  {
    id: "faq-03",
    category: "Flooring & Epoxy",
    question: "Can epoxy resin or microcement flooring be applied over my existing builder tiles?",
    answer: "Yes, in 85% of cases! If your existing tiles are structurally sound, well-adhered, and not loose, we do not need to demolish them. We use heavy planetary diamond grinders with industrial HEPA vacuums to grind off the slick tile glaze, inject any hollow cavities with structural bonding epoxy, apply a high-adhesion moisture mitigation primer, and pour the seamless resin surface directly on top (total buildup is only 3mm to 4mm). This eliminates messy tile debris, saves ₹80–₹120 per sq.ft. in demolition carting, and shaves 2 weeks off the timeline."
  },
  {
    id: "faq-04",
    category: "Execution & Supervision",
    question: "Do you hire random subcontractors or do you have an in-house team on site?",
    answer: "We never sub-contract our core civil, modular installation, or epoxy surface execution to unknown daily-wage labor. Every Anvaya project has a dedicated, full-time in-house site engineer present from 9:30 AM to 6:30 PM. Our site engineers supervise all laser alignments, manage society security protocols, coordinate material deliveries, and send you daily video and photographic progress updates via your client WhatsApp group."
  },
  {
    id: "faq-05",
    category: "Materials & Quality",
    question: "What grades of plywood, hardware, and surface laminates do you use?",
    answer: "We maintain a strict quality benchmark: all wet-zone cabinetry (kitchens, utility, bathroom vanities) is built exclusively using 100% Calibrated IS:710 Marine Grade BWP (Boiling Water Proof) Plywood with phenolic resin bonding. For dry bedroom wardrobes, we use calibrated hardwood plywood. All moving functional hardware—drawer runners, hinges, and lift-ups—is sourced directly from Blum (Austria) and Hettich (Germany). We encourage clients to visit our factory to inspect plywood cross-sections and hardware certifications before installation."
  },
  {
    id: "faq-06",
    category: "Warranty & Support",
    question: "What warranties do you provide, and what is your after-sales service policy in Pune?",
    answer: "We provide an official 10-Year Manufacturer Warranty on all Blum and Hettich mechanical moving hardware (hinges, drawer channels, lift-ups), a 10-Year Warranty against borer and termite delamination on IS:710 plywood, and a 5-Year Surface Integrity Warranty on our specialized epoxy and microcement resin floors. More importantly, we maintain an active local Pune service team with a committed 48-hour service turnaround for any alignment, hinge adjustment, or maintenance requests."
  },
  {
    id: "faq-07",
    category: "Design Consultation",
    question: "Is the initial design consultation and site visit chargeable?",
    answer: "Our first discovery session—whether held at our Baner studio or as an initial walk-through at your Pune property—is completely complimentary. We review your floor plan, assess spatial opportunities, discuss realistic investment budgets, and present material samples. Detailed 3D photorealistic renderings and working structural drawings are developed once the design engagement agreement is formalized."
  },
  {
    id: "faq-08",
    category: "Service Areas",
    question: "Which areas of Pune and PCMC do you actively service?",
    answer: "Our core execution footprint covers Baner, Balewadi, Aundh, Wakad, Hinjewadi (Phases 1, 2, and 3), Kharadi, Magarpatta City, Kalyani Nagar, Koregaon Park, Kothrud, Bavdhan, Model Colony, Viman Nagar, Ravet, and the Pimpri-Chinchwad municipal region. Because our manufacturing facility is located in Bhosari (PCMC) and our design studio is in Baner, our logistics and site engineers service both western and eastern Pune corridors seamlessly."
  }
];
