/**
 * Lumicentric Interiors - Company Configuration
 * Brand: Lumicentric (Mumbai, Maharashtra)
 */

export const COMPANY_CONFIG = {
  name: "Lumicentric",
  brandSubtitle: "Interior Design & Epoxy Flooring • Mumbai",
  logo: "assets/images/logo.png",
  logoHorizontal: "assets/images/logo-horizontal.png",
  logoHorizontalLight: "assets/images/logo-horizontal-light.png",
  logoIcon: "assets/images/logo-icon.png",
  legalName: "Lumicentric Interiors Pvt. Ltd.",
  tagline: "Thoughtful Spaces for Modern Living",
  heroEyebrow: "INTERIORS THAT FEEL LIKE HOME",
  heroSubtitle: "From concept to completion, we design and build beautiful, functional spaces that reflect your lifestyle in Mumbai.",
  locationBadge: "Mumbai, Maharashtra",
  address: {
    line1: "Prime Business Hub, Linking Road, Bandra West",
    locality: "Bandra West",
    city: "Mumbai",
    state: "Maharashtra",
    postalCode: "400050",
    country: "India",
    googleMapsUrl: "https://maps.google.com/?q=Bandra+West+Mumbai+Maharashtra+400050"
  },
  contact: {
    phoneDisplay: "+91 70390 71998",
    phoneCallable: "+917039071998",
    whatsappNumber: "917039071998",
    whatsappDefaultMessage: "Hello Lumicentric Interiors, I would like to discuss an interior design project in Mumbai.",
    email: "lumicentricinterior@gmail.com",
    workingHours: "Monday – Saturday: 10:00 AM – 7:30 PM (Consultations by Appointment)"
  },
  stats: [
    { value: "500+", label: "Projects Completed" },
    { value: "8+", label: "Years Experience" },
    { value: "Mumbai", label: "Our Base", isLocation: true }
  ],
  trustedBrands: [
    { name: "Lodha", logoText: "LODHA" },
    { name: "Godrej", logoText: "Godrej Properties" },
    { name: "Oberoi", logoText: "Oberoi Realty" },
    { name: "Piramal", logoText: "Piramal" },
    { name: "Hiranandani", logoText: "Hiranandani" },
    { name: "Tata Housing", logoText: "TATA Housing" },
    { name: "Mahindra", logoText: "Mahindra" },
    { name: "Shapoorji", logoText: "Shapoorji Pallonji" }
  ],
  serviceLocalities: [
    "Bandra West", "Juhu", "Worli", "Lower Parel", "Powai",
    "Khar", "Santacruz", "Prabhadevi", "Andheri West", "Lokhandwala",
    "Cuffe Parade", "Marine Drive", "Goregaon East", "Thane", "Navi Mumbai"
  ],
  socialLinks: {
    instagram: "https://www.instagram.com/aara.vsarkar/?hl=en",
    facebook: "https://www.facebook.com/profile.php?id=61595443570028"
  }
};
