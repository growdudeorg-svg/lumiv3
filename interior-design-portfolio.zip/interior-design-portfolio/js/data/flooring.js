/**
 * Specialised Flooring & Epoxy Resin Systems
 * Studio: Anvaya Atelier (Pune, Maharashtra)
 * Note: Engineering-first surface specifications and application steps.
 */

export const FLOORING_DATA = {
  sectionTitle: "Specialised Epoxy Resin & Seamless Flooring",
  tagline: "High-Performance Architectural Resin Systems Engineered for Pune Homes & Commercial Lofts",
  introduction: "Traditional tile grout lines harbor dirt, mold, and break visual flow. Our specialized flooring division designs and executes continuous, monolithic resinous floors directly over existing sound subfloors or fresh concrete. We combine industrial-grade surface preparation with bespoke decorative finishes that withstand Pune’s monsoon humidity and everyday wear.",
  
  stages: [
    {
      step: "01",
      name: "Mechanical Diamond Grinding",
      title: "Dust-Free Substrate Profiling",
      description: "We use three-phase planetary diamond grinders with magnetic diamond segments to grind off glaze, contaminants, and weak cement laitance. Connected to industrial M-class HEPA vacuums, the entire process is 98% dust-free.",
      specDetail: "Concrete Surface Profile (CSP) 2–3 achieved for mechanical resin mechanical anchor.",
      icon: "grinder"
    },
    {
      step: "02",
      name: "Moisture Vapor Barrier",
      title: "Penetrating Moisture-Tolerant Primer",
      description: "Subfloor moisture is the #1 cause of floor bubbles and delamination in Maharashtra's humid monsoon climate. We apply a 100% solids, low-viscosity penetrative epoxy primer that deeply enters concrete pores and blocks rising moisture vapor.",
      specDetail: "Tolerates relative humidity up to 88% and prevents capillary dampness.",
      icon: "barrier"
    },
    {
      step: "03",
      name: "Resin Body Coat Pour",
      title: "Self-Leveling Decorative Matrix (3mm–4mm)",
      description: "Premium Bisphenol-A epoxy resin enriched with liquid metallic pearl pigments, micro-aggregates, or vinyl terrazzo flakes. Hand-troweled and back-rolled with spiked rollers to release trapped air and form a perfectly flat, seamless plane.",
      specDetail: "100% solids formulation with zero evaporating solvents (Zero VOC).",
      icon: "pour"
    },
    {
      step: "04",
      name: "Protective Sealer Topcoat",
      title: "Aliphatic Polyurethane / Polyaspartic Shield",
      description: "We protect the decorative epoxy with two coats of UV-stable aliphatic polyurethane. Available in ultra-matte, satin, or glass-gloss sheen, this layer provides scratch resistance and prevents UV yellowing.",
      specDetail: "Shore D Hardness 80–85 with optional micronized glass bead anti-slip additive.",
      icon: "shield"
    }
  ],

  finishTypes: [
    {
      id: "metallic-flow",
      name: "3D Metallic Obsidian & Smoke",
      category: "Luxury Residential & Design Lofts",
      sheen: "Satin or High-Gloss Depth",
      description: "Pearlescent metallic pigments suspended in clear resin create organic, fluid ripples reminiscent of natural river stone or polished marble.",
      bestFor: "Living rooms, art galleries, executive cabins, penthouses.",
      thickness: "3.0 mm – 4.0 mm",
      features: ["Three-dimensional marble effect", "Seamless without joint lines", "Stain resistant", "Gentle barefoot feel"],
      image: "assets/images/flooring-metallic.svg"
    },
    {
      id: "microcement-matte",
      name: "Seamless Japandi Microcement",
      category: "Architectural Minimalist Living",
      sheen: "Warm Tactile Matte (Velvet Sheen)",
      description: "Continuous polymer-modified cementitious micro-topping with subtle trowel textures that deliver raw Scandinavian and Wabi-Sabi elegance.",
      bestFor: "Bedrooms, open-concept living rooms, boutique retail, master bathrooms.",
      thickness: "2.5 mm – 3.0 mm",
      features: ["Breathable mineral matrix", "Neutral earthy colorways", "Zero grout to clean", "Crack-bridging elasticity"],
      image: "assets/images/flooring-microcement.svg"
    },
    {
      id: "terrazzo-flake",
      name: "Polyaspartic Terrazzo Flake System",
      category: "High Impact & Utility Zones",
      sheen: "Textured Satin / Non-Slip",
      description: "Engineered vinyl flake broadcast embedded in colored resin base, sealed with clear polyaspartic. Incredible resilience to scuffs, vehicle tires, and outdoor weather.",
      bestFor: "Balconies, terraces, parking suites, gymnasiums, utility spaces.",
      thickness: "2.5 mm – 3.5 mm",
      features: ["Highest impact & scuff resistance", "100% UV non-yellowing outdoors", "Certified R10 anti-slip rating", "Fast 24-hr cure turnaround"],
      image: "assets/images/flooring-flake.svg"
    },
    {
      id: "high-build-solid",
      name: "Hygienic Solid Monolith Resin",
      category: "Commercial & Healthcare",
      sheen: "Semi-Gloss or Matte",
      description: "Solid uniform color resin floor with extreme chemical resistance and anti-bacterial seamless properties. Easily steam-cleaned or sanitized.",
      bestFor: "Medical clinics, commercial kitchens, recording studios, corporate server hubs.",
      thickness: "2.0 mm – 3.0 mm",
      features: ["Certified anti-bacterial surface", "Resistant to chemical cleaners & oils", "Zero crevices for germs", "Easy maintenance"],
      image: "assets/images/flooring-solid.svg"
    }
  ],

  technicalSpecs: [
    { label: "Compressive Strength", value: "75 MPa (ASTM D695)" },
    { label: "Tensile Strength", value: "28 MPa (ASTM D638)" },
    { label: "Surface Hardness", value: "Shore D 82–85 (ASTM D2240)" },
    { label: "Adhesion to Concrete", value: "> 3.2 MPa (Substrate failure before resin debonding)" },
    { label: "VOC Content", value: "< 10 g/L (Ultra-low emission, safe indoors)" },
    { label: "Foot Traffic Ready", value: "24–36 Hours at 25°C–30°C ambient temperature" }
  ],

  maintenanceGuide: [
    {
      title: "Daily & Weekly Cleaning",
      detail: "Clean with a dry microfiber dust mop or damp mop with pH-neutral soap water. Avoid harsh bleach, ammonia, or wire abrasive pads."
    },
    {
      title: "Furniture Protection",
      detail: "Apply felt pads under chairs, metal tables, and heavy credenzas. Rolling office chairs should use soft polyurethane castor wheels."
    },
    {
      title: "Pune Climate Resilience",
      detail: "Engineered to withstand Pune's wet monsoon humidity without blistering, thanks to our mandatory high-adhesion moisture mitigation primer."
    }
  ]
};
