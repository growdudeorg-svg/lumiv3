/**
 * Services Configuration matching exact UI design
 */

export const SERVICES_DATA = [
  {
    id: "modular-interiors",
    title: "Modular Interiors",
    shortDescription: "Sleek & functional modular kitchens, wardrobes and storage.",
    image: "assets/images/service-modular.jpg",
    category: "modular",
    timeline: "30-45 Days",
    deliverables: [
      "Precision German hardware (Blum & Hafele)",
      "Factory finished edge-banded Marine Ply carcass",
      "Soft-close tandem drawers & hydraulic lifts",
      "Quartz / Corian anti-scratch countertops",
      "Ergonomic workflow & custom pantry organizers"
    ],
    materials: "Century Pro Marine BWP 710 Plywood, Hafele Legrabox, Acrylic & PU Anti-Fingerprint Laminates",
    idealFor: "2BHK, 3BHK, 4BHK apartments and penthouses requiring high-durability modular utility."
  },
  {
    id: "turnkey-projects",
    title: "Turnkey Projects",
    shortDescription: "Design, execution and handover — all under one roof.",
    image: "assets/images/service-turnkey.jpg",
    category: "turnkey",
    timeline: "60-90 Days",
    deliverables: [
      "End-to-end design conceptualization & 3D visualizations",
      "Complete civil masonry, plumbing & electrical rewiring",
      "False ceiling with architectural cove lighting",
      "Bespoke fixed carpentry & loose furniture styling",
      "Single-point project manager & milestone sign-offs"
    ],
    materials: "Premium Italian Marble, Teakwood Veneers, Saint-Gobain Glass, Schneider Electric Automation",
    idealFor: "Homeowners seeking completely stress-free, move-in-ready turnkey delivery."
  },
  {
    id: "residential-interiors",
    title: "Residential Interiors",
    shortDescription: "Personalised spaces for modern living.",
    image: "assets/images/service-residential.jpg",
    category: "residential",
    timeline: "45-75 Days",
    deliverables: [
      "Custom master suite & bedroom acoustics",
      "Ambient lighting design & smart mood dimming",
      "Fluted acoustic paneling & wall moldings",
      "Custom upholstered headboards & vanity units",
      "Handpicked soft furnishings, rugs & artwork"
    ],
    materials: "Fluted Charcoal Louvers, Linen Sheers, Walnut Finishes, Brass Inlays",
    idealFor: "Luxury apartments, row houses, and boutique villas across Pune."
  },
  {
    id: "commercial-interiors",
    title: "Commercial Interiors",
    shortDescription: "Workspaces that inspire productivity.",
    image: "assets/images/service-commercial.jpg",
    category: "commercial",
    timeline: "40-60 Days",
    deliverables: [
      "High-efficiency executive suites & boardrooms",
      "Double-glazed acoustic glass partitions",
      "Ergonomic collaborative hot-desks & breakout zones",
      "Integrated AV conference tech & concealed cable raceways",
      "Commercial fire retardant materials & safety compliance"
    ],
    materials: "Dormakaba Glass Systems, Armstrong Acoustic Ceilings, Commercial Grade Vinyl",
    idealFor: "Tech offices in Hinjewadi, corporate headquarters in Baner, boutique studios."
  },
  {
    id: "flooring-solutions",
    title: "Flooring Solutions",
    shortDescription: "Tiles, wooden, vinyl and more.",
    image: "assets/images/service-flooring.jpg",
    category: "flooring",
    timeline: "10-20 Days",
    deliverables: [
      "Large-format Italian marble slab laying & diamond mirror polish",
      "European chevron & herringbone engineered hardwood",
      "Commercial SPC luxury acoustic vinyl planks",
      "Subfloor moisture sealing & laser level calibration",
      "Laser-cut brass threshold transition strips"
    ],
    materials: "Statuario / Botticino Italian Marble, Quick-Step Hardwood, Bona Polyurethane Sealers",
    idealFor: "Living lounges, master bedrooms, and high-traffic residential surfaces."
  },
  {
    id: "epoxy-resin-flooring",
    title: "Epoxy Resin Flooring",
    shortDescription: "Durable, seamless and premium finishes.",
    image: "assets/images/service-epoxy.jpg",
    category: "flooring",
    timeline: "7-14 Days",
    deliverables: [
      "100% seamless, joint-free resin surface application",
      "High-clarity metallic 3D marble vein effects",
      "Microcement & terrazzo seamless concrete aesthetics",
      "Monsoon moisture-barrier priming & anti-skid additives",
      "High-impact scratch & chemical resistant UV topcoat"
    ],
    materials: "Solvent-free High-Solid Epoxy Resins, Polyaspartic UV Guard, Metallic Mica Pigments",
    idealFor: "Penthouses, designer retail showrooms, cafes, and modern minimalist lofts."
  }
];
