/**
 * Lumicentric Interiors - Application Bootstrap & Dynamic Hydration
 * Brand: Lumicentric (Mumbai, Maharashtra)
 */

import { COMPANY_CONFIG } from './data/company.js';
import { SERVICES_DATA } from './data/services.js';
import { PROJECTS_DATA } from './data/projects.js';
import { CASE_STUDIES_DATA } from './data/caseStudies.js';
import { PROCESS_DATA } from './data/process.js';
import { TESTIMONIALS_DATA } from './data/testimonials.js';
import { ABOUT_DATA } from './data/about.js';

import { initComparisonSlider } from './components/comparisonSlider.js';
import { openProjectModalById, initProjectModal } from './components/projectModal.js';

document.addEventListener('DOMContentLoaded', () => {
  console.log('Lumicentric Luxury Portfolio Initializing...');

  // 1. Render Services
  renderServices();

  // 2. Render Featured Projects
  renderFeaturedProjects('all');

  // 3. Render Process Roadmap
  renderProcess();

  // 4. Render Testimonials
  renderTestimonials();

  // 5. Initialize Interactive Components
  initNavigation();
  initComparisonSlider();
  initProjectModal();
  initCategoryFilters();
  initVideoStoryModal();
  initCaseStudyTriggers();
  initEnquiryForm();
});

/* ==========================================================================
   Render Services (6 Cards Grid)
   ========================================================================== */
function renderServices() {
  const grid = document.getElementById('servicesGrid');
  if (!grid) return;

  grid.innerHTML = SERVICES_DATA.map(service => `
    <article class="service-card" data-service-id="${service.id}" tabindex="0" role="button" aria-label="View ${service.title} details">
      <div class="service-card-media">
        <img src="${service.image}" alt="${service.title}" width="300" height="200" loading="lazy" />
      </div>
      <h3 class="service-card-title">${service.title}</h3>
      <p class="service-card-desc">${service.shortDescription}</p>
      <div class="service-card-footer">
        <div class="circle-btn" aria-hidden="true">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><line x1="7" y1="17" x2="17" y2="7"></line><polyline points="7 7 17 7 17 17"></polyline></svg>
        </div>
      </div>
    </article>
  `).join('');

  // Add click listeners to open service detail in modal
  grid.querySelectorAll('.service-card').forEach(card => {
    card.addEventListener('click', () => {
      const id = card.dataset.serviceId;
      openServiceModal(id);
    });
    card.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        openServiceModal(card.dataset.serviceId);
      }
    });
  });
}

function openServiceModal(serviceId) {
  const service = SERVICES_DATA.find(s => s.id === serviceId);
  if (!service) return;

  const backdrop = document.getElementById('projectModalBackdrop');
  const dynamicContent = document.getElementById('modalDynamicContent');
  if (!backdrop || !dynamicContent) return;

  dynamicContent.innerHTML = `
    <div style="padding: 2.5rem 2rem;">
      <span class="eyebrow-label" style="color: var(--color-accent-gold);">SERVICE DIVISION</span>
      <h2 style="font-size: 2.2rem; margin-bottom: 0.5rem; color: #FFFFFF;">${service.title}</h2>
      <p style="color: #CCCCCC; font-size: 1.05rem; margin-bottom: 1.5rem;">${service.shortDescription}</p>

      <div style="width: 100%; height: 320px; border-radius: 12px; overflow: hidden; margin-bottom: 1.5rem;">
        <img src="${service.image}" alt="${service.title}" style="width: 100%; height: 100%; object-fit: cover;" />
      </div>

      <div style="margin-bottom: 1.5rem;">
        <h4 style="color: #FFFFFF; font-size: 1.1rem; margin-bottom: 0.75rem;">Deliverables &amp; Inclusions</h4>
        <ul style="color: #B5B5B5; line-height: 1.8; padding-left: 1.25rem;">
          ${service.deliverables.map(d => `<li>${d}</li>`).join('')}
        </ul>
      </div>

      <div style="background: #222; padding: 1.25rem; border-radius: 8px; margin-bottom: 2rem;">
        <div style="color: #E6DACB; font-weight: 600; font-size: 0.9rem; margin-bottom: 0.25rem;">Engineered Specifications:</div>
        <div style="color: #AAAAAA; font-size: 0.88rem;">${service.materials}</div>
        <div style="color: #888888; font-size: 0.82rem; margin-top: 0.5rem;">Typical Project Timeline: ${service.timeline}</div>
      </div>

      <a href="#contact" class="btn btn-pill-gold" onclick="document.getElementById('projectModalBackdrop').classList.remove('active'); document.getElementById('projectType').value='${service.title}';">
        Discuss This Service &rarr;
      </a>
    </div>
  `;

  backdrop.classList.add('active');
  backdrop.setAttribute('aria-hidden', 'false');
}

/* ==========================================================================
   Render Featured Projects (4 Cards Grid with Filtering)
   ========================================================================== */
function renderFeaturedProjects(category = 'all') {
  const grid = document.getElementById('projectsGrid');
  if (!grid) return;

  const filtered = category === 'all'
    ? PROJECTS_DATA.slice(0, 4)
    : PROJECTS_DATA.filter(p => p.category === category || category === 'all');

  grid.innerHTML = filtered.map(project => `
    <article class="project-card" data-project-id="${project.id}" tabindex="0" role="button" aria-label="View case study for ${project.title}">
      <div class="project-card-media">
        <img src="${project.coverImage}" alt="${project.title} Mumbai" width="400" height="280" loading="lazy" />
      </div>
      <div class="project-card-info">
        <div class="project-card-text">
          <h3 class="project-card-title">${project.title}</h3>
          <div class="project-card-meta">${project.categoryLabel} &bull; ${project.location.split(',')[0]}</div>
        </div>
        <div class="circle-btn circle-btn-dark" aria-hidden="true">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><line x1="7" y1="17" x2="17" y2="7"></line><polyline points="7 7 17 7 17 17"></polyline></svg>
        </div>
      </div>
    </article>
  `).join('');

  // Project card click opens modal
  grid.querySelectorAll('.project-card').forEach(card => {
    card.addEventListener('click', () => {
      openProjectModalById(card.dataset.projectId);
    });
    card.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        openProjectModalById(card.dataset.projectId);
      }
    });
  });
}

function initCategoryFilters() {
  const pills = document.querySelectorAll('.filter-pill');
  pills.forEach(pill => {
    pill.addEventListener('click', () => {
      pills.forEach(p => {
        p.classList.remove('active');
        p.setAttribute('aria-selected', 'false');
      });
      pill.classList.add('active');
      pill.setAttribute('aria-selected', 'true');
      renderFeaturedProjects(pill.dataset.category);
    });
  });
}

/* ==========================================================================
   Render Process (6 Steps Timeline)
   ========================================================================== */
function renderProcess() {
  const container = document.getElementById('processTimeline');
  if (!container) return;

  container.innerHTML = PROCESS_DATA.map(item => `
    <div class="process-step-item">
      <div class="process-step-icon">
        ${item.icon}
      </div>
      <div class="process-step-info">
        <div class="process-step-num">${item.step}</div>
        <div class="process-step-title">${item.name}</div>
        <div class="process-step-short">${item.short}</div>
      </div>
    </div>
  `).join('');
}

/* ==========================================================================
   Render Testimonials (3 Cards)
   ========================================================================== */
function renderTestimonials() {
  const grid = document.getElementById('testimonialsGrid');
  if (!grid) return;

  grid.innerHTML = TESTIMONIALS_DATA.map(t => `
    <div class="testimonial-card">
      <div class="testimonial-quote-icon">&ldquo;</div>
      <p class="testimonial-quote-text">&ldquo;${t.quote}&rdquo;</p>
      <div class="testimonial-client-row">
        <div class="testimonial-avatar">
          <img src="${t.avatar}" alt="${t.clientName} testimonial avatar" width="44" height="44" loading="lazy" />
        </div>
        <div>
          <div class="testimonial-client-name">${t.clientName}</div>
          <div class="testimonial-client-role">${t.role}</div>
        </div>
      </div>
    </div>
  `).join('');
}

/* ==========================================================================
   Watch Our Story Video Modal
   ========================================================================== */
function initVideoStoryModal() {
  const trigger = document.getElementById('watchStoryBtn');
  const backdrop = document.getElementById('videoModalBackdrop');
  const closeBtn = document.getElementById('closeVideoModalBtn');
  const enquiryCta = document.getElementById('videoEnquiryCta');

  if (!trigger || !backdrop) return;

  const openVideo = () => {
    backdrop.classList.add('active');
    backdrop.setAttribute('aria-hidden', 'false');
  };

  const closeVideo = () => {
    backdrop.classList.remove('active');
    backdrop.setAttribute('aria-hidden', 'true');
  };

  trigger.addEventListener('click', openVideo);
  if (closeBtn) closeBtn.addEventListener('click', closeVideo);
  if (enquiryCta) enquiryCta.addEventListener('click', closeVideo);

  backdrop.addEventListener('click', (e) => {
    if (e.target === backdrop) closeVideo();
  });

  window.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && backdrop.classList.contains('active')) {
      closeVideo();
    }
  });
}

/* ==========================================================================
   Case Study Trigger
   ========================================================================== */
function initCaseStudyTriggers() {
  const btn = document.getElementById('openCaseStudyModalBtn');
  if (!btn) return;

  btn.addEventListener('click', () => {
    const caseStudy = CASE_STUDIES_DATA[0];
    const backdrop = document.getElementById('projectModalBackdrop');
    const dynamicContent = document.getElementById('modalDynamicContent');
    if (!backdrop || !dynamicContent) return;

    dynamicContent.innerHTML = `
      <div style="padding: 2.5rem 2rem;">
        <span class="eyebrow-label" style="color: var(--color-accent-gold);">${caseStudy.eyebrow}</span>
        <h2 style="font-size: 2.2rem; color: #FFFFFF; margin-bottom: 0.5rem;">${caseStudy.title}</h2>
        <div style="color: #A0A0A0; font-size: 0.95rem; margin-bottom: 1.5rem;">${caseStudy.subtitle} &bull; ${caseStudy.area} &bull; ${caseStudy.timeline} Delivery</div>

        <div style="width: 100%; height: 360px; border-radius: 12px; overflow: hidden; margin-bottom: 2rem;">
          <img src="${caseStudy.image}" alt="${caseStudy.title}" style="width: 100%; height: 100%; object-fit: cover;" />
        </div>

        <h3 style="color: #FFFFFF; font-size: 1.25rem; margin-bottom: 1.25rem;">Execution Phases</h3>
        <div style="display: flex; flex-direction: column; gap: 1rem; margin-bottom: 2rem;">
          ${caseStudy.deepPhases.map(p => `
            <div style="background: #222; padding: 1.25rem; border-radius: 8px; border-left: 3px solid var(--color-accent-gold);">
              <div style="display: flex; justify-content: space-between; margin-bottom: 0.35rem;">
                <strong style="color: #FFF;">${p.phase}</strong>
                <span style="color: var(--color-accent-gold); font-size: 0.85rem;">${p.duration}</span>
              </div>
              <p style="color: #B0B0B0; font-size: 0.88rem; line-height: 1.6;">${p.details}</p>
            </div>
          `).join('')}
        </div>

        <a href="#contact" class="btn btn-pill-gold" onclick="document.getElementById('projectModalBackdrop').classList.remove('active');">
          Enquire About Similar Project &rarr;
        </a>
      </div>
    `;

    backdrop.classList.add('active');
    backdrop.setAttribute('aria-hidden', 'false');
  });
}

/* ==========================================================================
   Navigation Scroll & Mobile Menu
   ========================================================================== */
function initNavigation() {
  const header = document.querySelector('.site-header');
  const toggle = document.getElementById('mobileNavToggle');
  const drawer = document.getElementById('mobile-nav-drawer');

  // Sticky header scroll elevation
  window.addEventListener('scroll', () => {
    if (window.scrollY > 30) {
      header.classList.add('scrolled');
    } else {
      header.classList.remove('scrolled');
    }
  }, { passive: true });

  // Mobile menu toggle
  if (toggle && drawer) {
    toggle.addEventListener('click', () => {
      const isOpen = drawer.classList.contains('open');
      drawer.classList.toggle('open', !isOpen);
      toggle.classList.toggle('is-active', !isOpen);
      toggle.setAttribute('aria-expanded', String(!isOpen));
      drawer.setAttribute('aria-hidden', String(isOpen));
      document.body.style.overflow = !isOpen ? 'hidden' : '';
    });

    drawer.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        drawer.classList.remove('open');
        toggle.classList.remove('is-active');
        toggle.setAttribute('aria-expanded', 'false');
        drawer.setAttribute('aria-hidden', 'true');
        document.body.style.overflow = '';
      });
    });
  }

  // Smooth scroll
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
      const targetId = this.getAttribute('href');
      if (targetId === '#') return;
      const target = document.querySelector(targetId);
      if (target) {
        e.preventDefault();
        target.scrollIntoView({ behavior: 'smooth' });
      }
    });
  });
}

/* ==========================================================================
   Contact Form Submission & WhatsApp Sync
   ========================================================================== */
function initEnquiryForm() {
  const form = document.getElementById('enquiryForm');
  const feedback = document.getElementById('formFeedback');
  if (!form) return;

  form.addEventListener('submit', (e) => {
    e.preventDefault();

    const name = document.getElementById('userName').value.trim();
    const phone = document.getElementById('userPhone').value.trim();
    const projectType = document.getElementById('projectType').value;
    const message = document.getElementById('userMessage').value.trim();

    if (!name || !phone) {
      feedback.style.display = 'block';
      feedback.style.color = '#FF6B6B';
      feedback.textContent = 'Please provide both your name and phone number.';
      return;
    }

    const ticketId = 'LUM-MUM-2026-' + Math.floor(1000 + Math.random() * 9000);

    feedback.style.display = 'block';
    feedback.style.color = '#74C0FC';
    feedback.innerHTML = `
      <div style="background: rgba(255,255,255,0.06); padding: 1.25rem; border-radius: 8px; border: 1px solid rgba(255,255,255,0.15); margin-top: 0.5rem;">
        <strong style="color: #FFF; font-size: 1.05rem;">Thank you, ${name}!</strong><br />
        <p style="color: #D0D0D0; font-size: 0.9rem; margin: 0.5rem 0 1rem;">Your consultation request has been received (Ticket: <code style="color: var(--color-accent-gold); font-weight: 700;">${ticketId}</code>). Our Mumbai studio team will contact you at <strong>${phone}</strong> within 24 hours.</p>
        <a href="https://wa.me/917039071998?text=Hello%20Lumicentric%20Interiors,%20I%20just%20submitted%20consultation%20ticket%20${ticketId}%20for%20a%20project%20in%20Mumbai." class="btn btn-pill-gold btn-sm" target="_blank" rel="noopener noreferrer">
          Instant WhatsApp Follow-up &rarr;
        </a>
      </div>
    `;

    // Reset fields
    form.reset();
  });
}
