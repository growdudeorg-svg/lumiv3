/**
 * Accessible FAQ Accordion Component
 * Studio: Anvaya Atelier (Pune, Maharashtra)
 */

import { FAQS_DATA } from '../data/faqs.js';
import { trackEvent } from './analytics.js';

export function initFaqAccordion() {
  const container = document.querySelector('.faq-list');
  if (!container) return;

  container.innerHTML = FAQS_DATA.map((faq, index) => `
    <div class="faq-item" id="faq-item-${index}">
      <button 
        class="faq-trigger" 
        aria-expanded="${index === 0 ? 'true' : 'false'}"
        aria-controls="faq-content-${index}"
        id="faq-btn-${index}"
      >
        <span>${faq.question}</span>
        <svg class="faq-chevron" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <polyline points="6 9 12 15 18 9"></polyline>
        </svg>
      </button>
      <div 
        class="faq-content" 
        id="faq-content-${index}" 
        role="region" 
        aria-labelledby="faq-btn-${index}"
        style="${index === 0 ? 'display: block;' : 'display: none;'}"
      >
        <p>${faq.answer}</p>
      </div>
    </div>
  `).join('');

  // Mark first item active by default
  const firstItem = container.querySelector('#faq-item-0');
  if (firstItem) firstItem.classList.add('active');

  // Attach click & keyboard listeners
  const triggers = container.querySelectorAll('.faq-trigger');
  triggers.forEach((trigger, idx) => {
    trigger.addEventListener('click', () => {
      const item = trigger.closest('.faq-item');
      const content = item?.querySelector('.faq-content');
      const isExpanded = trigger.getAttribute('aria-expanded') === 'true';

      // Toggle state
      if (isExpanded) {
        trigger.setAttribute('aria-expanded', 'false');
        item?.classList.remove('active');
        if (content) content.style.display = 'none';
      } else {
        trigger.setAttribute('aria-expanded', 'true');
        item?.classList.add('active');
        if (content) content.style.display = 'block';
        trackEvent('faq_expanded', { questionId: FAQS_DATA[idx]?.id });
      }
    });
  });
}
