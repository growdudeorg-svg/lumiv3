/**
 * Specialised Flooring & Epoxy Resin Systems Component
 * Studio: Anvaya Atelier (Pune, Maharashtra)
 */

import { FLOORING_DATA } from '../data/flooring.js';
import { trackEvent } from './analytics.js';

export function initFlooringExplorer() {
  const container = document.querySelector('.flooring-showcase-container');
  if (!container) return;

  container.innerHTML = `
    <!-- 4-Stage Surface Preparation & Application -->
    <div class="flooring-block">
      <div class="section-header">
        <span class="section-label">Surface Engineering</span>
        <h3>The 4-Stage Preparation &amp; Application Protocol</h3>
        <p class="section-subtitle">
          Over 90% of epoxy floor failures in India result from poor subfloor preparation. We utilize industrial diamond grinding and moisture barriers before applying decorative resins.
        </p>
      </div>

      <div class="flooring-stages-grid">
        ${FLOORING_DATA.stages.map(st => `
          <div class="stage-card">
            <div class="stage-number">${st.step}</div>
            <div class="stage-name">${st.name}</div>
            <h4 class="stage-title">${st.title}</h4>
            <p class="stage-desc">${st.description}</p>
            <div class="stage-spec-badge">${st.specDetail}</div>
          </div>
        `).join('')}
      </div>
    </div>

    <!-- 4 Curated Finish Systems -->
    <div class="flooring-block" style="margin-top: var(--space-4xl);">
      <div class="section-header">
        <span class="section-label">Curated Finishes</span>
        <h3>Architectural Resin &amp; Microcement Finishes</h3>
        <p class="section-subtitle">
          Continuous, joint-free surfaces engineered for residential luxury, creative lofts, and commercial durability in Pune.
        </p>
      </div>

      <div class="finishes-grid">
        ${FLOORING_DATA.finishTypes.map(f => `
          <div class="finish-card">
            <div class="finish-media">
              <img src="${f.image}" alt="${f.name}" class="finish-image" loading="lazy" />
            </div>
            <div class="finish-content">
              <span class="finish-category">${f.category}</span>
              <h4 class="finish-name">${f.name}</h4>
              <span class="finish-sheen">${f.sheen} • ${f.thickness}</span>
              <p class="finish-desc">${f.description}</p>
              <div class="finish-features-list">
                ${f.features.map(feat => `
                  <div class="finish-feature-item">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
                    <span>${feat}</span>
                  </div>
                `).join('')}
              </div>
            </div>
          </div>
        `).join('')}
      </div>
    </div>

    <!-- Technical Specs & Maintenance -->
    <div class="flooring-block" style="margin-top: var(--space-4xl);">
      <div class="flooring-specs-panel">
        <div class="section-header" style="margin-bottom: var(--space-lg);">
          <span class="section-label">Verified Testing</span>
          <h3>Verified Physical &amp; Chemical Specifications</h3>
          <p class="section-subtitle">Laboratory-tested ASTM benchmarks for compressive strength, adhesion, and hardness.</p>
        </div>

        <div class="flooring-specs-grid">
          ${FLOORING_DATA.technicalSpecs.map(spec => `
            <div class="flooring-spec-box">
              <div class="flooring-spec-key">${spec.label}</div>
              <div class="flooring-spec-value">${spec.value}</div>
            </div>
          `).join('')}
        </div>
      </div>
    </div>

    <!-- Maintenance Guidance for Pune Climate -->
    <div class="flooring-block" style="margin-top: var(--space-2xl);">
      <div class="flooring-maintenance-strip">
        ${FLOORING_DATA.maintenanceGuide.map(guide => `
          <div class="maintenance-card">
            <h4 class="maintenance-title">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path></svg>
              ${guide.title}
            </h4>
            <p class="maintenance-desc">${guide.detail}</p>
          </div>
        `).join('')}
      </div>
    </div>
  `;

  trackEvent('flooring_explorer_rendered');
}
