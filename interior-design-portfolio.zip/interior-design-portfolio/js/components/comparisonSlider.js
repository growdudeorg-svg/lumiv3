/**
 * Accessible Before-and-After Comparison Slider
 * Brand: Lumicentric (Mumbai, Maharashtra)
 */

export const COMPARISONS_DATA = [
  {
    id: "serenity-living",
    title: "From Outdated to Outstanding",
    description: "A tired living room turned into a warm, modern space with better lighting, storage and flow.",
    category: "Residential Interior",
    location: "Worli, Mumbai",
    beforeImage: "assets/images/comparison-before.jpg",
    afterImage: "assets/images/comparison-after.jpg"
  },
  {
    id: "modular-kitchen-transformation",
    title: "Cluttered Galley to Monolith Studio",
    description: "Replaced an outdated dark kitchen with seamless quartz island, Fenix matte acrylic shutters, and warm hidden LED task lighting.",
    category: "Modular Kitchen",
    location: "Powai, Mumbai",
    beforeImage: "assets/images/project-kitchen-before.svg",
    afterImage: "assets/images/service-modular.jpg"
  },
  {
    id: "epoxy-loft-transformation",
    title: "Cracked Tiles to Seamless Mirror Epoxy",
    description: "Diamond-grinded worn out glazed tiles, eliminated grout lines, and poured a high-clarity 3.5mm reflective resin floor.",
    category: "Flooring Solution",
    location: "Lower Parel, Mumbai",
    beforeImage: "assets/images/project-epoxy-before.svg",
    afterImage: "assets/images/project-epoxy-showroom.jpg"
  }
];

export function initComparisonSlider() {
  const box = document.getElementById('comparisonSliderBox');
  const divider = document.getElementById('comparisonDivider');
  const beforeWrapper = document.getElementById('comparisonBeforeWrapper');
  const beforeImg = document.getElementById('comparisonBeforeImg');
  const afterImg = document.getElementById('comparisonAfterImg');
  const titleEl = document.getElementById('transformationCardTitle');
  const descEl = document.getElementById('transformationCardDesc');
  const prevBtn = document.getElementById('prevComparisonBtn');
  const nextBtn = document.getElementById('nextComparisonBtn');

  if (!box || !divider || !beforeWrapper) return;

  let isDragging = false;
  let activeIndex = 0;

  function updateSlider(percent) {
    const clamped = Math.max(0, Math.min(100, percent));
    divider.style.left = `${clamped}%`;
    beforeWrapper.style.clipPath = `inset(0 ${100 - clamped}% 0 0)`;
  }

  function handleMove(e) {
    if (!isDragging) return;
    const rect = box.getBoundingClientRect();
    const clientX = e.clientX || (e.touches && e.touches[0].clientX) || 0;
    const pos = ((clientX - rect.left) / rect.width) * 100;
    updateSlider(pos);
  }

  function startDrag(e) {
    isDragging = true;
    handleMove(e);
  }

  function stopDrag() {
    isDragging = false;
  }

  box.addEventListener('mousedown', startDrag);
  window.addEventListener('mousemove', handleMove);
  window.addEventListener('mouseup', stopDrag);

  box.addEventListener('touchstart', startDrag, { passive: true });
  window.addEventListener('touchmove', handleMove, { passive: true });
  window.addEventListener('touchend', stopDrag);

  // Keyboard navigation
  box.addEventListener('keydown', (e) => {
    const current = parseFloat(divider.style.left || '50');
    if (e.key === 'ArrowLeft') {
      updateSlider(current - 5);
      e.preventDefault();
    } else if (e.key === 'ArrowRight') {
      updateSlider(current + 5);
      e.preventDefault();
    } else if (e.key === 'Home') {
      updateSlider(0);
      e.preventDefault();
    } else if (e.key === 'End') {
      updateSlider(100);
      e.preventDefault();
    }
  });

  // Cycle through transformations
  function loadComparison(index) {
    activeIndex = (index + COMPARISONS_DATA.length) % COMPARISONS_DATA.length;
    const item = COMPARISONS_DATA[activeIndex];
    
    beforeImg.src = item.beforeImage;
    afterImg.src = item.afterImage;
    if (titleEl) titleEl.textContent = item.title;
    if (descEl) descEl.textContent = item.description;

    updateSlider(50);
  }

  if (prevBtn) {
    prevBtn.addEventListener('click', () => loadComparison(activeIndex - 1));
  }
  if (nextBtn) {
    nextBtn.addEventListener('click', () => loadComparison(activeIndex + 1));
  }

  // Initial set
  updateSlider(50);
}
