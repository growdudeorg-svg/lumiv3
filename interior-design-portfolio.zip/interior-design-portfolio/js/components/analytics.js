/**
 * Client-Side Analytics & Event Dispatcher
 * Tracks project engagement, CTA conversions, phone/WhatsApp interactions, and form events.
 */

export function trackEvent(eventName, payload = {}) {
  const eventData = {
    event: eventName,
    timestamp: new Date().toISOString(),
    url: window.location.href,
    ...payload
  };

  // 1. Dispatch custom DOM event for potential third-party tags (GTM, GA4)
  const customEvent = new CustomEvent('anvaya_analytics', { detail: eventData });
  window.dispatchEvent(customEvent);

  // 2. Also log to console for development verification
  if (process.env?.NODE_ENV !== 'production') {
    console.log(`[ANVAYA ANALYTICS] ${eventName}:`, payload);
  }

  // 3. Store recent events in session storage for debug audit
  try {
    const history = JSON.parse(sessionStorage.getItem('anvaya_events') || '[]');
    history.push(eventData);
    if (history.length > 50) history.shift();
    sessionStorage.setItem('anvaya_events', JSON.stringify(history));
  } catch (err) {
    // Ignore storage errors in restricted contexts
  }
}
