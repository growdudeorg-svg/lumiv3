/**
 * Featured Project Portfolio Component & Category Filtering
 * Studio: Anvaya Atelier (Pune, Maharashtra)
 */

import { PROJECTS_DATA } from '../data/projects.js';
import { openProjectModalById } from './projectModal.js';
import { trackEvent } from './analytics.js';

export function initPortfolio() {
  const gridContainer = document.querySelector('.projects-grid');
  const filterButtons = document.querySelectorAll('.portfolio-filter-bar .filter-btn');

  if (!gridContainer) return;

  let activeCategory = 'all';

  function renderProjects(category) {
    const filtered = category === 'all' 
      ? PROJECTS_DATA 
      : PROJECTS_DATA.filter(p => p.category === category);

    gridContainer.innerHTML = filtered.map(project => `
      <article 
        class="project-card" 
        tabindex="0" 
        role="button" 
        aria-label="View case details for ${project.title}"
        data-project-id="${project.id}"
      >
        <div class="project-card-media">
          <img 
            src="${project.coverImage}" 
            alt="${project.title} - ${project.location}" 
            class="project-card-image" 
            loading="lazy"
          />
          <div class="project-card-overlay">
            <div class="project-card-top-badges">
              <span class="badge badge-accent">${project.categoryLabel}</span>
              <span class="badge badge-status">${project.completionStatus.split('•')[0].trim()}</span>
            </div>
            <div class="project-card-bottom-tags">
              ${project.scopeTags.slice(0, 3).map(tag => `<span class="scope-tag">${tag}</span>`).join('')}
            </div>
          </div>
        </div>

        <div class="project-card-content">
          <h3 class="project-card-title">${project.title}</h3>
          <div class="project-card-location">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
            ${project.location}
          </div>
          <p class="project-card-subtitle">${project.subtitle}</p>

          <div class="project-card-footer">
            <span class="text-muted" style="font-size: 0.8rem; font-family: var(--font-mono);">${project.area} • ${project.year}</span>
            <span class="project-card-cta">
              Case Details
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>
            </span>
          </div>
        </div>
      </article>
    `).join('');

    // Attach click and keyboard events to project cards
    const cards = gridContainer.querySelectorAll('.project-card');
    cards.forEach(card => {
      const pId = card.getAttribute('data-project-id');

      card.addEventListener('click', () => {
        if (pId) openProjectModalById(pId);
      });

      card.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          if (pId) openProjectModalById(pId);
        }
      });
    });
  }

  // Filter Buttons Handling
  filterButtons.forEach(btn => {
    btn.addEventListener('click', function() {
      const category = this.getAttribute('data-filter');
      if (category === activeCategory) return;

      activeCategory = category;

      // Update button active state
      filterButtons.forEach(b => {
        b.classList.remove('active');
        b.setAttribute('aria-pressed', 'false');
      });
      this.classList.add('active');
      this.setAttribute('aria-pressed', 'true');

      // Re-render
      renderProjects(category);
      trackEvent('portfolio_filter_changed', { category });
    });
  });

  // Initial render
  renderProjects('all');
}
