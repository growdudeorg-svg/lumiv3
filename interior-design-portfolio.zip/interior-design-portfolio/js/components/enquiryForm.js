/**
 * High-Conversion Project Enquiry Form & WhatsApp Sync
 * Studio: Anvaya Atelier (Pune, Maharashtra)
 */

import { COMPANY_CONFIG } from '../data/company.js';
import { trackEvent } from './analytics.js';

export function initEnquiryForm() {
  const form = document.querySelector('#project-enquiry-form');
  const submitBtn = form?.querySelector('button[type="submit"]');
  const successBanner = document.querySelector('.form-success-banner');
  const ticketBadge = document.querySelector('.ticket-number-badge');
  const resetBtn = document.querySelector('.form-reset-btn');
  const whatsappSyncLink = document.querySelector('.form-whatsapp-sync-btn');
  const projectTypeRadios = form?.querySelectorAll('input[name="project_type"]');
  const localitySelect = form?.querySelector('#enquiry-locality');
  const nameInput = form?.querySelector('#enquiry-name');
  const phoneInput = form?.querySelector('#enquiry-phone');
  const reqInput = form?.querySelector('#enquiry-requirement');

  if (!form) return;

  // 1. Dynamic WhatsApp Pre-Filled Link Generator
  function updateWhatsAppLink() {
    if (!whatsappSyncLink) return;

    const selectedType = form.querySelector('input[name="project_type"]:checked')?.value || 'Turnkey Interiors';
    const locality = localitySelect?.value || 'Pune';
    const clientName = nameInput?.value.trim() || 'Homeowner';

    const text = encodeURIComponent(
      `Hello Anvaya Atelier team, I am ${clientName}. I would like to discuss ${selectedType} for my property in ${locality}, Pune. Please share your availability for a consultation.`
    );

    whatsappSyncLink.href = `https://wa.me/${COMPANY_CONFIG.contact.whatsappNumber}?text=${text}`;
  }

  form.addEventListener('input', updateWhatsAppLink);
  projectTypeRadios?.forEach(r => r.addEventListener('change', updateWhatsAppLink));
  localitySelect?.addEventListener('change', updateWhatsAppLink);
  updateWhatsAppLink(); // Initial

  // 2. Field Validation Helper
  function validateField(inputEl, condition, errorMsg) {
    const group = inputEl.closest('.form-group');
    const errorEl = group?.querySelector('.form-error-msg');

    if (!condition) {
      inputEl.classList.add('is-invalid');
      group?.classList.add('has-error');
      if (errorEl) errorEl.textContent = errorMsg;
      return false;
    } else {
      inputEl.classList.remove('is-invalid');
      group?.classList.remove('has-error');
      return true;
    }
  }

  // 3. Indian Phone Number Validation (10 digits starting with 6, 7, 8, 9)
  function isValidIndianPhone(phone) {
    const cleaned = phone.replace(/[\s\-\+\(\)]/g, '');
    const regex = /^(?:91)?[6789]\d{9}$/;
    return regex.test(cleaned);
  }

  // Live input cleanup for phone
  phoneInput?.addEventListener('input', () => {
    if (phoneInput.value.trim().length >= 10) {
      validateField(
        phoneInput, 
        isValidIndianPhone(phoneInput.value), 
        "Please enter a valid 10-digit Indian mobile number."
      );
    }
  });

  // 4. Form Submission Handling
  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    // Validation checks
    const isNameValid = validateField(
      nameInput,
      nameInput.value.trim().length >= 2,
      "Please enter your full name (minimum 2 characters)."
    );

    const isPhoneValid = validateField(
      phoneInput,
      isValidIndianPhone(phoneInput.value),
      "Please enter a valid 10-digit Indian mobile number (e.g. 98230 44820)."
    );

    const isLocalityValid = validateField(
      localitySelect,
      localitySelect.value.trim() !== '',
      "Please select or specify your property locality in Pune."
    );

    const isReqValid = validateField(
      reqInput,
      reqInput.value.trim().length >= 8,
      "Please provide brief details of your property (BHK, carpet area, status)."
    );

    if (!isNameValid || !isPhoneValid || !isLocalityValid || !isReqValid) {
      // Focus first invalid field
      const firstInvalid = form.querySelector('.is-invalid');
      firstInvalid?.focus();
      return;
    }

    // Set Loading State
    submitBtn?.classList.add('is-loading');
    submitBtn?.setAttribute('disabled', 'true');

    trackEvent('form_submission_started', {
      locality: localitySelect.value,
      projectType: form.querySelector('input[name="project_type"]:checked')?.value
    });

    try {
      // Simulate network request with 1.2 second latency
      await new Promise(resolve => setTimeout(resolve, 1200));

      // Generate verifiable ticket code
      const randomSuffix = Math.floor(1000 + Math.random() * 9000);
      const ticketNumber = `ANV-PUN-2026-${randomSuffix}`;

      // Populate Ticket
      if (ticketBadge) ticketBadge.textContent = `Ticket Ref: ${ticketNumber}`;

      // Show Success Banner & Hide Form
      form.style.display = 'none';
      successBanner?.classList.add('visible');

      trackEvent('form_submission_success', {
        ticketNumber,
        locality: localitySelect.value
      });

      // Update success WhatsApp link with ticket number
      const successWhatsAppBtn = document.querySelector('.success-whatsapp-btn');
      if (successWhatsAppBtn) {
        const text = encodeURIComponent(
          `Hi Anvaya Atelier, I submitted an enquiry on your website (Ticket: ${ticketNumber}). Looking forward to our project discussion.`
        );
        successWhatsAppBtn.href = `https://wa.me/${COMPANY_CONFIG.contact.whatsappNumber}?text=${text}`;
      }

    } catch (err) {
      alert("Submission encountered an unexpected error. Please call our Baner studio directly or connect via WhatsApp.");
      trackEvent('form_submission_failed', { error: err.message });
    } finally {
      submitBtn?.classList.remove('is-loading');
      submitBtn?.removeAttribute('disabled');
    }
  });

  // 5. Reset Form Capability
  resetBtn?.addEventListener('click', () => {
    form.reset();
    form.style.display = 'flex';
    successBanner?.classList.remove('visible');
    updateWhatsAppLink();
    trackEvent('form_reset_clicked');
  });

  // 6. Direct Contact Tracking (Phone / WhatsApp / Brochure)
  document.querySelectorAll('a[href^="tel:"]').forEach(link => {
    link.addEventListener('click', () => {
      trackEvent('phone_call_clicked', { number: link.getAttribute('href') });
    });
  });

  document.querySelectorAll('a[href*="wa.me"]').forEach(link => {
    link.addEventListener('click', () => {
      trackEvent('whatsapp_chat_clicked', { url: link.getAttribute('href') });
    });
  });
}
