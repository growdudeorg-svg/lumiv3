/**
 * Accessible Project Detail Modal
 * Studio: Anvaya Atelier (Pune, Maharashtra)
 */

import { PROJECTS_DATA } from '../data/projects.js';
import { trackEvent } from './analytics.js';

let previouslyFocusedElement = null;

export function openProjectModalById(projectId) {
  const project = PROJECTS_DATA.find(p => p.id === projectId);
  if (!project) return;

  const backdrop = document.querySelector('.modal-backdrop');
  const modal = document.querySelector('.project-modal');
  const modalContent = document.querySelector('.modal-dynamic-content');

  if (!backdrop || !modal || !modalContent) return;

  previouslyFocusedElement = document.activeElement;

  // Build Modal Inner HTML
  modalContent.innerHTML = `
    <!-- Modal Header Bar -->
    <div class="modal-header-bar">
      <div class="modal-header-info">
        <span class="modal-location-badge">${project.location} • ${project.area}</span>
        <h3 class="modal-title">${project.title}</h3>
      </div>
      <button class="modal-close-btn" aria-label="Close Project Modal">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <line x1="18" y1="6" x2="6" y2="18"></line>
          <line x1="6" y1="6" x2="18" y2="18"></line>
        </svg>
      </button>
    </div>

    <!-- Modal Body -->
    <div class="modal-body">
      <!-- Hero Media Banner -->
      <div class="modal-hero-media">
        <img src="${project.coverImage}" alt="${project.title}" class="modal-hero-image" />
      </div>

      <!-- Quick Metrics Strip -->
      <div class="modal-stats-bar">
        <div class="modal-stat-item">
          <span class="modal-stat-label">Location</span>
          <span class="modal-stat-val">${project.location}</span>
        </div>
        <div class="modal-stat-item">
          <span class="modal-stat-label">Area</span>
          <span class="modal-stat-val">${project.area}</span>
        </div>
        <div class="modal-stat-item">
          <span class="modal-stat-label">Scope</span>
          <span class="modal-stat-val">${project.categoryLabel}</span>
        </div>
        <div class="modal-stat-item">
          <span class="modal-stat-label">Status</span>
          <span class="modal-stat-val" style="color:#5cd28d;">${project.completionStatus}</span>
        </div>
      </div>

      <!-- Narrative Grid (Brief, Challenges, Design Decisions, Execution Approach) -->
      <div class="modal-narrative-grid">
        <div class="narrative-block">
          <h4 class="narrative-heading">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg>
            Project Brief
          </h4>
          <p class="narrative-text">${project.brief}</p>
        </div>

        <div class="narrative-block">
          <h4 class="narrative-heading">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="12 2 2 22 22 22"></polygon><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>
            Challenges Overcome
          </h4>
          <ul class="narrative-list">
            ${project.challenges.map(c => `<li class="narrative-list-item">${c}</li>`).join('')}
          </ul>
        </div>

        <div class="narrative-block">
          <h4 class="narrative-heading">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><path d="M12 6v6l4 2"></path></svg>
            Design Direction & Solutions
          </h4>
          <ul class="narrative-list">
            ${project.designDecisions.map(d => `<li class="narrative-list-item">${d}</li>`).join('')}
          </ul>
        </div>

        <div class="narrative-block">
          <h4 class="narrative-heading">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
            Execution & Quality Control
          </h4>
          <ul class="narrative-list">
            ${project.executionApproach.map(e => `<li class="narrative-list-item">${e}</li>`).join('')}
          </ul>
        </div>
      </div>

      <!-- Verified Material Specifications -->
      <div class="specs-table-wrapper">
        <h4 class="narrative-heading">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect><line x1="3" y1="9" x2="21" y2="9"></line><line x1="9" y1="21" x2="9" y2="9"></line></svg>
          Verified Material & Technical Specifications
        </h4>
        <table class="specs-table">
          <tbody>
            ${Object.entries(project.verifiedSpecs).map(([key, val]) => `
              <tr>
                <th>${key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())}</th>
                <td>${val}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>

      <!-- Image Gallery -->
      ${project.gallery && project.gallery.length > 0 ? `
        <div class="modal-gallery-box">
          <h4 class="narrative-heading" style="margin-bottom: 1rem;">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect><circle cx="8.5" cy="8.5" r="1.5"></circle><polyline points="21 15 16 10 5 21"></polyline></svg>
            Curated Space Gallery (${project.gallery.length} Perspectives)
          </h4>
          <div class="modal-gallery-strip">
            ${project.gallery.map(img => `
              <div class="modal-gallery-thumb">
                <img src="${img.url}" alt="${img.caption}" title="${img.caption}" />
              </div>
            `).join('')}
          </div>
        </div>
      ` : ''}

      <!-- Video Walkthrough Simulation -->
      ${project.videoWalkthrough ? `
        <div class="modal-video-box">
          <h4 class="narrative-heading">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg>
            Project Video Tour (${project.videoWalkthrough.duration})
          </h4>
          <div class="video-player-simulation">
            <img src="${project.videoWalkthrough.poster}" alt="${project.videoWalkthrough.title}" class="video-player-poster" />
            <button class="video-play-overlay-btn" aria-label="Play Walkthrough Video">
              <svg width="28" height="28" viewBox="0 0 24 24" fill="currentColor">
                <polygon points="5 3 19 12 5 21 5 3"></polygon>
              </svg>
            </button>
          </div>
          <p class="narrative-text" style="font-size:0.86rem; color:var(--color-text-muted);">${project.videoWalkthrough.description}</p>
        </div>
      ` : ''}

      <!-- Client Testimonial -->
      ${project.testimonial ? `
        <div class="modal-quote-block">
          <p class="modal-quote-text">“${project.testimonial.quote}”</p>
          <div class="modal-quote-author">— ${project.testimonial.clientName}, ${project.testimonial.society}</div>
        </div>
      ` : ''}

      <!-- Modal Bottom Enquiry CTA -->
      <div class="modal-footer-cta">
        <div class="modal-footer-cta-text">
          <h4>Inspired by ${project.title}?</h4>
          <p>Schedule a private site walkthrough or discuss your Pune home layout with our architects.</p>
        </div>
        <button class="btn btn-primary modal-enquire-btn" data-project-title="${project.title}" data-project-category="${project.category}">
          Discuss Similar Project
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>
        </button>
      </div>
    </div>
  `;

  // Show Modal
  backdrop.classList.add('open');
  backdrop.setAttribute('aria-hidden', 'false');
  document.body.style.overflow = 'hidden';

  // Attach Close Listeners
  const closeBtn = modalContent.querySelector('.modal-close-btn');
  closeBtn?.addEventListener('click', closeProjectModal);
  closeBtn?.focus();

  // Attach Enquire CTA
  const enquireBtn = modalContent.querySelector('.modal-enquire-btn');
  enquireBtn?.addEventListener('click', () => {
    const category = enquireBtn.getAttribute('data-project-category');
    closeProjectModal();

    // Select project type in form
    if (category) {
      const radio = document.querySelector(`input[name="project_type"][value="${category}"]`);
      if (radio) {
        radio.checked = true;
        radio.dispatchEvent(new Event('change'));
      }
    }

    // Scroll to contact section
    const contactSection = document.querySelector('#contact');
    if (contactSection) {
      const headerHeight = document.querySelector('.site-header')?.offsetHeight || 80;
      const targetPos = contactSection.getBoundingClientRect().top + window.scrollY - headerHeight;
      window.scrollTo({ top: targetPos, behavior: 'smooth' });
    }
  });

  trackEvent('project_modal_opened', { projectId, title: project.title });
}

export function closeProjectModal() {
  const backdrops = document.querySelectorAll('.modal-backdrop');
  backdrops.forEach(backdrop => {
    backdrop.classList.remove('open');
    backdrop.classList.remove('active');
    backdrop.setAttribute('aria-hidden', 'true');
  });
  document.body.style.overflow = '';

  if (previouslyFocusedElement) {
    previouslyFocusedElement.focus();
  }

  trackEvent('project_modal_closed');
}

export function initProjectModal() {
  const backdrop = document.querySelector('.modal-backdrop');

  // Close when clicking directly on backdrop
  backdrop?.addEventListener('click', (e) => {
    if (e.target === backdrop) {
      closeProjectModal();
    }
  });

  // Close on ESC key & trap focus
  window.addEventListener('keydown', (e) => {
    if (!backdrop?.classList.contains('open')) return;

    if (e.key === 'Escape') {
      closeProjectModal();
    }

    // Trap focus inside modal
    if (e.key === 'Tab') {
      const focusableEls = backdrop.querySelectorAll(
        'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
      );
      const firstEl = focusableEls[0];
      const lastEl = focusableEls[focusableEls.length - 1];

      if (e.shiftKey) {
        if (document.activeElement === firstEl) {
          e.preventDefault();
          lastEl?.focus();
        }
      } else {
        if (document.activeElement === lastEl) {
          e.preventDefault();
          firstEl?.focus();
        }
      }
    }
  });
}
