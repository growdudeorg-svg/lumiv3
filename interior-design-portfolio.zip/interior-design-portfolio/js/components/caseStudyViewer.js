/**
 * Selected Case Studies Viewer (Deep Dive On-Page Component)
 * Studio: Anvaya Atelier (Pune, Maharashtra)
 */

import { CASE_STUDIES_DATA } from '../data/caseStudies.js';
import { openProjectModalById } from './projectModal.js';
import { trackEvent } from './analytics.js';

export function initCaseStudies() {
  const container = document.querySelector('.case-studies-container');
  if (!container) return;

  container.innerHTML = CASE_STUDIES_DATA.map((cs, idx) => `
    <article class="case-study-item" id="${cs.id}">
      <div class="case-study-hero-grid">
        <div class="case-study-media-pane">
          <img src="${cs.coverImage}" alt="${cs.title}" loading="lazy" />
        </div>
        <div class="case-study-overview-pane">
          <div class="case-study-meta-strip">
            <span class="badge badge-accent">${cs.location}</span>
            <span class="badge badge-status">${cs.duration}</span>
          </div>
          <h3 class="case-study-title">${cs.title}</h3>
          <p class="case-study-subtitle">${cs.subtitle}</p>
          <div class="case-study-client-req">
            <strong style="color:var(--color-text-primary); display:block; margin-bottom:4px;">Client Brief &amp; Lifestyle Context:</strong>
            ${cs.clientRequirement}
          </div>
          <div>
            <button class="btn btn-secondary btn-sm case-study-open-modal-btn" data-project-id="${cs.projectId}">
              Explore Full Technical Dossier
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>
            </button>
          </div>
        </div>
      </div>

      <!-- Execution Phases Grid -->
      <div class="case-study-details-accordion">
        <div class="case-study-phases-grid">
          <div class="phase-box">
            <h4 class="phase-box-title">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="12 2 2 22 22 22"></polygon></svg>
              Site Challenges Overcome
            </h4>
            <ul class="phase-box-list">
              ${cs.projectChallenges.map(c => `<li class="phase-box-item">${c}</li>`).join('')}
            </ul>
          </div>

          <div class="phase-box">
            <h4 class="phase-box-title">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><path d="M12 6v6l4 2"></path></svg>
              Design Direction &amp; Spatial Flow
            </h4>
            <p style="font-size:0.88rem; color:var(--color-text-secondary); line-height:1.6;">${cs.designDirection}</p>
          </div>

          <div class="phase-box">
            <h4 class="phase-box-title">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect><line x1="3" y1="9" x2="21" y2="9"></line><line x1="9" y1="21" x2="9" y2="9"></line></svg>
              Materials &amp; Precision Specs
            </h4>
            <ul class="phase-box-list">
              ${cs.materialsAndPlanning.map(m => `<li class="phase-box-item">${m}</li>`).join('')}
            </ul>
          </div>
        </div>
      </div>

      <!-- Verified Outcomes & Feedback Footer -->
      <div class="case-study-footer-bar">
        <div class="outcomes-list">
          <strong style="font-size:0.82rem; text-transform:uppercase; letter-spacing:0.08em; color:var(--color-accent-primary); display:block; margin-bottom:4px;">
            Verified Project Outcomes:
          </strong>
          ${cs.verifiedOutcomes.map(out => `
            <div class="outcome-item">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
              <span>${out}</span>
            </div>
          `).join('')}
        </div>

        <div class="case-study-quote">
          “${cs.clientFeedback.quote}”
          <div class="case-study-quote-author">— ${cs.clientFeedback.author}</div>
        </div>
      </div>
    </article>
  `).join('');

  // Attach modal trigger listeners
  container.querySelectorAll('.case-study-open-modal-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const pId = btn.getAttribute('data-project-id');
      if (pId) {
        openProjectModalById(pId);
        trackEvent('case_study_modal_opened', { projectId: pId });
      }
    });
  });
}
